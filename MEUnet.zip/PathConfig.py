
from LibConfig import *
from ParamConfig import *

####################################################
####                   FILENAMES               ####
####################################################

# Data filename
if SimulateData:
    tagD0 = '_combined'
    tagV0 = 'velocity_model_c1_'
    tagD1 = 'obsz'
    tagV1 = 'c1'
else:
    tagD0 = 'srec'
    tagV0 = 'svmodel'
    tagD1 = 'Rec'
    tagV1 = 'svmodel'

datafilename = tagD0
dataname = tagD1
truthfilename = tagV0
truthname = tagV1



###################################################
####                   PATHS                  #####
###################################################
 
main_dir = './MEUnet/'

## Check the main directory
if len(main_dir) == 0:
    raise Exception('Please specify path to correct directory!')
    
    
## Data path
if os.path.exists('./MEUnet/data/'):
    data_dir = main_dir + 'data/'
else:
    os.makedirs('./MEUnet/data/')
    data_dir = main_dir + 'data/'
    
# Define training/testing data directory

train_data_dir = data_dir + 'train_data/'
test_data_dir = data_dir + 'test_data/'
    
# Define directory for simulate data and SEG data respectively
if SimulateData:
    train_data_dir = train_data_dir + 'SimulateData/'
    test_data_dir = test_data_dir + 'SimulateData/'
else:
    train_data_dir = train_data_dir + 'FieldData/'
    test_data_dir = test_data_dir + 'FieldData/'
    

    
    
## Create Results and Models path
if os.path.exists('./MEUnet/results/') and os.path.exists('./MEUnet/models/'):
    results_dir = main_dir + 'results/'
    models_dir = main_dir + 'models/'
else:
    os.makedirs('./MEUnet/results/')
    os.makedirs('./MEUnet/models/')
    results_dir = main_dir + 'results/'
    models_dir = main_dir + 'models/'
    
if SimulateData:
    results_dir = results_dir + 'SimulateResults/'
    models_dir = models_dir + 'SimulataModel/'
else:
    results_dir = results_dir + 'FieldResults/'
    models_dir = models_dir + 'FieldModel/'
    
if os.path.exists(results_dir) and os.path.exists(models_dir):  
    results_dir = results_dir
    models_dir = models_dir
else:
    os.makedirs(results_dir)
    os.makedirs(models_dir)
    results_dir = results_dir
    models_dir = models_dir

# Create Model name
if SimulateData:
    tagM = 'Simulate'
else:
    tagM = 'Field'
tagM0 = '_MEUnetModel'
tagM1 = '_TrainSize' + str(TrainSize)
tagM2 = '_Epoch' + str(Epochs)
tagM3 = '_BatchSize' + str(BatchSize)
tagM4 = '_LR' + str(LearnRate)

modelname = tagM+tagM0+tagM1+tagM2+tagM3+tagM4



