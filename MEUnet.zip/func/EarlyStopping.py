import numpy as np
import torch
import os

class EarlyStopping:
    """Early stops the training if validation loss doesn't improve after a given patience."""
    def __init__(self, save_path, patience=15, verbose=False, delta=1e-4):
        """
        Args:
            save_path :
            patience (int): How long to wait after last time validation loss improved.
                            Default: 7
            verbose (bool): If True, prints a message for each validation loss improvement.
                            Default: False
            delta (float): Minimum change in the monitored quantity to qualify as an improvement.
                            Default: 0
        """
        self.save_path = save_path
        self.patience = patience
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = np.Inf
        self.delta = delta
        self.best_epoch = None
        self.stop_epoch = None

    def __call__(self, val_loss, net, lamda=None, epoch=None):

        score = -val_loss

        if self.best_score is None:
            self.best_score = score
            self.save_checkpoint(val_loss, net, lamda, epoch)
        elif score < self.best_score + self.delta:
            self.counter += 1
            print(f'EarlyStopping counter: {self.counter} out of {self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
                self.stop_epoch = epoch
        else:
            self.best_score = score
            self.save_checkpoint(val_loss, net, lamda, epoch)
            self.counter = 0

    def save_checkpoint(self, val_loss, net, lamda, epoch):
        '''Saves model when validation loss decrease.'''
        if self.verbose:
            print(f'Validation loss decreased ({self.val_loss_min:.6f} --> {val_loss:.6f}).  Saving model ...')

        torch.save(net.state_dict(), self.save_path + '_lamda' + str(lamda) + '_dropout_best' + '.pkl')
        self.val_loss_min = val_loss
        self.best_epoch = epoch

