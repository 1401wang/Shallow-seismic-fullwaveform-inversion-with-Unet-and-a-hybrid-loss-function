import numpy as np
from skimage.measure import block_reduce
import scipy.io
from sklearn.model_selection import train_test_split


def DataLoad_Train_Val(total_size, train_data_dir, data_dim, in_channels, model_dim, data_dsp_blk, label_dsp_blk, start,
                   datafilename, dataname, truthfilename, truthname, val_ratio):
    all_train_set = None
    all_label_set = None

    for i in range(start, start + total_size):
        filename_seis = train_data_dir + 'georec_train/' + 'model_' + str(i) + datafilename

        data1_set = scipy.io.loadmat(filename_seis)
        data1_set = np.float32(data1_set[str(dataname)].reshape([data_dim[0], data_dim[1], in_channels]))

        for k in range(in_channels):
            data11_set = np.float32(data1_set[:, :, k])
            data11_set = np.float32(data11_set)

            data11_set = block_reduce(data11_set, block_size=data_dsp_blk, func=decimate)
            data_dsp_dim = data11_set.shape
            data11_set = data11_set.reshape(1, data_dsp_dim[0]*data_dsp_dim[1])

            if k == 0:
                train1_set = data11_set
            else:
                train1_set = np.concatenate((train1_set, data11_set), axis=0)

        filename_label = train_data_dir + 'vmodel_train/' + truthfilename + str(i)
        data2_set = scipy.io.loadmat(filename_label)
        data2_set = np.float32(data2_set[str(truthname)].reshape(model_dim))

        data2_set = block_reduce(data2_set, block_size=label_dsp_blk, func=np.max)
        label_dsp_dim = data2_set.shape
        data2_set = data2_set.reshape(1, label_dsp_dim[0]*label_dsp_dim[1])
        data2_set = np.float32(data2_set)

        if all_train_set is None:
            all_train_set = np.zeros((total_size, in_channels, data_dsp_dim[0] * data_dsp_dim[1]), dtype=np.float32)
            all_label_set = np.zeros((total_size, 1, label_dsp_dim[0] * label_dsp_dim[1]), dtype=np.float32)


        all_train_set[i - start, :, :] = train1_set
        all_label_set[i - start, 0, :] = data2_set

    train_set, val_set, train_label, val_label = train_test_split(
        all_train_set, all_label_set, test_size=val_ratio, random_state=42, shuffle=False
    )

    mean = np.mean(train_set, axis=(0, 2), keepdims=True)
    std = np.std(train_set, axis=(0, 2), keepdims=True) + 1e-8
    np.save('train_mean.npy', mean)
    np.save('train_std.npy', std)
    train_set = (train_set - mean) / std
    val_set = (val_set - mean) / std

    return train_set, train_label, val_set, val_label, data_dsp_dim, label_dsp_dim


def decimate(a, axis):
    idx = np.round((np.array(a.shape)[np.array(axis).reshape(1, -1)] + 1.0) / 2.0 - 1).reshape(-1)
    downa = np.array(a)[:, :, idx[0].astype(int), idx[1].astype(int)]
    return downa
