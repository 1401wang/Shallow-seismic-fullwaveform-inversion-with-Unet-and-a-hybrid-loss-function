####################################################
# ###             MAIN PARAMETERS                ####
####################################################
SimulateData = True
ReUse = False
TestSize = False
DataDim = [1800, 48]
data_dsp_blk = (12, 1)
ModelDim = [20, 48]
label_dsp_blk = (1, 1)
dh = 0.5
Val_ratio = 0.2
TotalSize = 640
####################################################
# ###             NETWORK PARAMETERS             ####
####################################################
if SimulateData:
    Epochs = 100
    TrainSize = TotalSize - TotalSize * Val_ratio
    ValSize = TotalSize * Val_ratio
    ValBatchSize = 16
    TestSize = 4
    TestBatchSize = 1
else:
    Epochs = 100
    TrainSize = 100
    TestSize = 1
    TestBatchSize = 1
    
BatchSize = 16
LearnRate = 1e-3
Nclasses = 1
Inchannels = 6
SaveEpoch = 10
DisplayStep = 2

