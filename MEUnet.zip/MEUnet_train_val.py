
from matplotlib import font_manager

################################################
########        IMPORT LIBARIES         ########
################################################

from ParamConfig import *
from PathConfig import *
from LibConfig import *
import os

from func.DataLoad_Train_Val import DataLoad_Train_Val
from func.EarlyStopping import EarlyStopping
import pandas as pd

os.environ['CUDA_LAUNCH_BLOCKING'] = '1'

# import os
import torch

torch.cuda.empty_cache()

################################################
########             NETWORK            ########
################################################


cuda_available = torch.cuda.is_available()
device = torch.device("cuda" if cuda_available else "cpu")

Drop_out = True
net = UnetModel(n_classes=Nclasses, in_channels=Inchannels, is_deconv=True, is_batchnorm=True)
if torch.cuda.is_available():

    net = nn.DataParallel(net)

net = net.to(device)

optimizer = torch.optim.Adam(net.parameters(), lr=LearnRate)


################################################
########    LOADING TRAINING DATA       ########
################################################
print('***************** Loading Training DataSet *****************')
train_set, train_label, val_set, val_label, data_dsp_dim, label_dsp_dim = DataLoad_Train_Val(total_size=TotalSize, train_data_dir=train_data_dir,
                                                                   data_dim=DataDim, in_channels=Inchannels,
                                                                   model_dim=ModelDim, data_dsp_blk=data_dsp_blk,
                                                                   label_dsp_blk=label_dsp_blk, start=1,
                                                                   datafilename=datafilename, dataname=dataname,
                                                                   truthfilename=truthfilename, truthname=truthname, val_ratio=Val_ratio)

train = data_utils.TensorDataset(torch.from_numpy(train_set), torch.from_numpy(train_label))
train_loader = data_utils.DataLoader(train, batch_size=BatchSize, shuffle=True)

########################################################################################################################
########################################################################################################################

val = data_utils.TensorDataset(torch.from_numpy(val_set), torch.from_numpy(val_label))
val_loader = data_utils.DataLoader(val, batch_size=ValBatchSize, shuffle=False)


# ###############################################
# #######            TRAINING            ########
# ###############################################

print()
print('*******************************************')
print('*******************************************')
print('           START TRAINING                  ')
print('*******************************************')
print('*******************************************')
print()

print('Original data dimention:%s' % str(DataDim))
print('Downsampled data dimention:%s ' % str(data_dsp_dim))
print('Original label dimention:%s' % str(ModelDim))
print('Downsampled label dimention:%s' % str(label_dsp_dim))
print('Training size:%d' % int(TrainSize))
print('Traning batch size:%d' % int(BatchSize))
print('Validation size:%d' % int(ValSize))
print('Number of epochs:%d' % int(Epochs))
print('Learning rate:%.5f' % float(LearnRate))

# Initialization
early_stopping = EarlyStopping(save_path=models_dir + modelname)
loss1 = 0.0
loss2 = 0.0
step = np.int_(TrainSize / BatchSize)
step2 = np.int_(ValSize / BatchSize)
start = time.time()
loss_list1 = []
loss_list2 = []
lamda = 1
best_val_loss = float('inf')
best_epoch = -1

mse_list1 = []
mse_list2 = []
edge_list1 = []
edge_list2 = []

contrib_mse_list = []
contrib_edge_list = []

alpha_list = []
beta_list = []

psnr_list = []
ssim_list = []
r_2_list = []


for epoch in range(Epochs):
    alpha = max(0, 1 - epoch / Epochs)   # MSE 权重逐渐减小
    beta = min(1, epoch / Epochs)        # EdgeLoss 权重逐渐增大
    # start train
    train_epoch_loss = 0.0
    val_epoch_loss = 0.0
    mse_train_epoch_loss = 0.0
    mse_val_epoch_loss = 0.0
    edge_train_epoch_loss = 0.0
    edge_val_epoch_loss = 0.0
    contrib_mse = 0
    contrib_edge = 0

    psnr_epoch = 0.0
    ssim_epoch = 0.0
    r_2_epoch = 0.0
    count = 0

    since = time.time()
    for i, (train_images, train_labels) in enumerate(train_loader):
        iteration1 = epoch * step + i + 1

        net.train()

        # Reshape data size
        train_images = train_images.view(BatchSize, Inchannels, data_dsp_dim[0], data_dsp_dim[1])
        train_labels = train_labels.view(BatchSize, Nclasses, label_dsp_dim[0], label_dsp_dim[1])
        train_images = train_images.to(device)
        train_labels = train_labels.to(device)


        optimizer.zero_grad()
        torch.cuda.empty_cache()


        outputs1 = net(train_images, label_dsp_dim)

        train_loss1 = beta * edge_loss(outputs1, train_labels)
        train_loss2 = alpha * F.mse_loss(outputs1, train_labels, reduction='mean')
        train_loss = train_loss1 + train_loss2


        if np.isnan(float(train_loss.item())):
            raise ValueError('train_loss is nan while training')

        train_epoch_loss += train_loss.item() / (len(train_loader))
        mse_train_epoch_loss += F.mse_loss(outputs1, train_labels, reduction='mean').item() / (len(train_loader))
        edge_train_epoch_loss += edge_loss(outputs1, train_labels).item() / (len(train_loader))
        contrib_mse += (train_loss2.item()) / (train_loss.item() + 1e-12)
        contrib_edge += (train_loss1.item()) / (train_loss.item() + 1e-12)

        train_loss.backward()
        optimizer.step()


        if iteration1 % DisplayStep == 0:
            print('Epoch: {}/{}, Iteration: {}/{} --- Training Loss:{:.6f}'.format(epoch + 1,
                                                                                   Epochs, iteration1,
                                                                                   step * Epochs, train_loss.item()))
    ##############################################################################################

    for j, (val_images, val_labels) in enumerate(val_loader):
        net.eval()
        iteration2 = epoch * step2 + j + 1

        val_images = val_images.view(ValBatchSize, Inchannels, data_dsp_dim[0], data_dsp_dim[1])
        val_labels = val_labels.view(ValBatchSize, Nclasses, label_dsp_dim[0], label_dsp_dim[1])
        val_images = val_images.to(device)
        val_labels = val_labels.to(device)

        with torch.no_grad():
            outputs2 = net(val_images, label_dsp_dim)
            val_loss1 = beta * edge_loss(outputs2, val_labels)
            val_loss2 = alpha * F.mse_loss(outputs2, val_labels, reduction='mean')
            val_loss = val_loss1 + val_loss2


            if np.isnan(float(val_loss.item())):
                raise ValueError('loss is nan while training')

            val_epoch_loss += val_loss.item() / (len(val_loader))
            mse_val_epoch_loss += F.mse_loss(outputs2, val_labels, reduction='mean').item() / (len(val_loader))
            edge_val_epoch_loss += edge_loss(outputs2, val_labels).item() / (len(val_loader))

            if iteration2 % DisplayStep == 0:
                print('Epoch: {}/{}, Iteration: {}/{} --- Validation Loss:{:.6f}'.format(epoch + 1,
                                                                                       Epochs, iteration2,
                                                                                       step2 * Epochs,
                                                                                       val_loss.item()))


            outs = outputs2.view(ValBatchSize, label_dsp_dim[0], label_dsp_dim[1]).cpu().numpy()
            gts = val_labels.view(ValBatchSize, label_dsp_dim[0], label_dsp_dim[1]).cpu().numpy()

            for k in range(outs.shape[0]):
                pred, gt = turn(outs[k]), turn(gts[k])
                ssim_val = SSIM(pred.reshape(-1, 1, *pred.shape), gt.reshape(-1, 1, *gt.shape))
                psnr_epoch += PSNR(pred, gt)
                ssim_epoch += float(ssim_val.detach().cpu().item() if isinstance(ssim_val, torch.Tensor) else ssim_val)
                r_2_epoch += r2_score(pred, gt)
                count += 1

    loss_list1.append(train_epoch_loss)
    loss_list2.append(val_epoch_loss)
    mse_list1.append(mse_train_epoch_loss)
    mse_list2.append(mse_val_epoch_loss)
    edge_list1.append(edge_train_epoch_loss)
    edge_list2.append(edge_val_epoch_loss)
    alpha_list.append(alpha)
    beta_list.append(beta)
    contrib_mse /= len(train_loader)
    contrib_edge /= len(train_loader)
    contrib_mse_list.append(contrib_mse)
    contrib_edge_list.append(contrib_edge)

    if count > 0:
        psnr_list.append(psnr_epoch / count)
        ssim_list.append(ssim_epoch / count)
        r_2_list.append(r_2_epoch / count)
        print(f"Epoch {epoch + 1}: PSNR={psnr_list[-1]:.2f}, SSIM={ssim_list[-1]:.4f}")


    if val_epoch_loss < best_val_loss:
        best_val_loss = val_epoch_loss
        best_epoch = epoch + 1


    if (epoch + 1) % 1 == 0:
        print(f"Epoch: {epoch + 1}, Train_loss:{train_epoch_loss:.4f}, Val_loss: {val_epoch_loss:.4f}")
        time_elapsed = time.time() - since
        print('Epoch consuming time: {:.0f}m {:.0f}s'.format(time_elapsed // 60, time_elapsed % 60))


    if (epoch + 1) % SaveEpoch == 0:
        torch.save(net.state_dict(), models_dir + modelname + '_epoch' + str(epoch + 1) +'_lamda' + str(lamda) + '_dropout' + '.pkl')
        print('Trained model saved: %d percent completed' % int((epoch + 1) * 100 / Epochs))

    if epoch + 1 >= 1:
        early_stopping(val_epoch_loss, net, lamda=lamda, epoch=epoch+1)
        SaveTrainLoss(epoch, Epochs, loss_list1, loss_list2, SavePath=results_dir, early_stopping=early_stopping)
        # if early_stopping.early_stop:
        #     print(f"Early stopping triggered at epoch {early_stopping.stop_epoch}"
        #           f"Best model was at epoch {early_stopping.best_epoch}.")
        #     break   # 跳出迭代，结束训练
    else:
        SaveTrainLoss(epoch, Epochs, loss_list1, loss_list2, SavePath=results_dir, early_stopping=None)


Saveloss(Epochs, mse_list1, mse_list2, edge_list1, edge_list2, SavePath=results_dir)
plot_weight(alpha_list, beta_list, SavePath=results_dir)
plot_contri(contrib_mse_list, contrib_edge_list, SavePath=results_dir)

pd.DataFrame({
    "Epoch": range(1, len(psnr_list)+1),
    "PSNR": psnr_list,
    "SSIM": ssim_list,
    "R^2": r_2_list
}).to_csv(os.path.join(results_dir, "psnr_ssim_results.csv"), index=False)





time_elapsed = time.time() - start
print('Training complete in {:.0f}m  {:.0f}s'.format(time_elapsed // 60, time_elapsed % 60))

result_dict = {
    'Param_LR': LearnRate,
    'Param_BatchSize': BatchSize,
    'Param_Lambda': lamda,
    'Best_Val_Loss': best_val_loss,
    'Best_Epoch': best_epoch
}

result_df = pd.DataFrame([result_dict])
result_file = os.path.join(results_dir, 'hyperparam_results.csv')

if not os.path.exists(result_file):
    result_df.to_csv(result_file, index=False)
else:
    result_df.to_csv(result_file, mode='a', header=False, index=False)

print(f"✅ Best val loss: {best_val_loss:.6f} at epoch {best_epoch}, saved to {result_file}")

