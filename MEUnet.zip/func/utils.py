import torch
import numpy as np
import torch.nn as nn
from math import log10

from matplotlib import font_manager
from matplotlib.lines import Line2D
from scipy.io import savemat
from scipy.ndimage import zoom
from torch.autograd import Variable
from math import exp
import torch.nn.functional as F
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import scipy.io
from mpl_toolkits.axes_grid1 import make_axes_locatable
from matplotlib.colors import LogNorm
from torch import Tensor, einsum
from mpl_toolkits.axes_grid1.inset_locator import inset_axes



def turn(GT):
    dim = GT.shape
    for j in range(0, dim[1]):
        for i in range(0, dim[0]//2):
            temp = GT[i, j]
            GT[i, j] = GT[dim[0]-1-i, j]
            GT[dim[0]-1-i, j] = temp
    return GT 


def PSNR(prediction, target):
    prediction = Variable(torch.from_numpy(prediction))
    target = Variable(torch.from_numpy(target))
    zero = torch.zeros_like(target)
    criterion = nn.MSELoss(reduction='mean')
    MSE = criterion(prediction, target)
    total = criterion(target, zero)
    psnr = 10. * log10(total.item() / MSE.item())
    return psnr

def psnr(prediction, target):
    mse = F.mse_loss(prediction, target)
    zero = torch.zeros_like(target)
    max_val = F.mse_loss(zero, target)
    psnr = 10*torch.log10(max_val / (mse+1e-8))
    return psnr

def r2_score(y_true, y_pred):
    y_true = np.array(y_true)
    y_pred = np.array(y_pred)
    ss_res = np.sum((y_true - y_pred) ** 2)
    ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
    return 1 - ss_res / ss_tot

def gaussian(window_size, sigma):
    gauss = torch.Tensor([exp(-(x - window_size // 2) ** 2 / float(2 * sigma ** 2)) for x in range(window_size)])
    return gauss / gauss.sum()


def create_window(window_size, channel):
    _1D_window = gaussian(window_size, 1.5).unsqueeze(1)
    _2D_window = _1D_window.mm(_1D_window.t()).float().unsqueeze(0).unsqueeze(0)
    window = Variable(_2D_window.expand(channel, 1, window_size, window_size).contiguous())
    return window


def _ssim(img1, img2, window, window_size, channel, size_average=True):
    mu1 = F.conv2d(img1, window, padding=window_size // 2, groups=channel)
    mu2 = F.conv2d(img2, window, padding=window_size // 2, groups=channel)

    mu1_sq = mu1.pow(2)
    mu2_sq = mu2.pow(2)
    mu1_mu2 = mu1 * mu2

    sigma1_sq = F.conv2d(img1 * img1, window, padding=window_size // 2, groups=channel) - mu1_sq
    sigma2_sq = F.conv2d(img2 * img2, window, padding=window_size // 2, groups=channel) - mu2_sq
    sigma12 = F.conv2d(img1 * img2, window, padding=window_size // 2, groups=channel) - mu1_mu2
    L  = 255
    C1 = (0.01*L) ** 2
    C2 = (0.03*L) ** 2

    ssim_map = ((2 * mu1_mu2 + C1) * (2 * sigma12 + C2)) / ((mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2))

    if size_average:
        return ssim_map.mean()
    else:
        return ssim_map.mean(1).mean(1).mean(1)



def SSIM(img1, img2, window_size=11, size_average=True):
    img1 = Variable(torch.from_numpy(img1))
    img2 = Variable(torch.from_numpy(img2))
    (_, channel, _, _) = img1.size()
    window = create_window(window_size, channel)

    if img1.is_cuda:
        window = window.cuda(img1.get_device())
    window = window.type_as(img1)

    return _ssim(img1, img2, window, window_size, channel, size_average)



def SaveTrainLoss(epoch, Epochs, loss_list, loss_list2, SavePath, early_stopping):
    font_label = {'family': 'Times New Roman', 'size': 23}
    font_title = {'family': 'Times New Roman', 'size': 27}
    font_ticks = {'family': 'Times New Roman', 'size': 21}
    font_legend = font_manager.FontProperties(family='Times New Roman', size=21, weight='bold')
    if (epoch+1) % 1 == 0:

        plt.style.use("seaborn-v0_8")
        plt.figure(1)
        plt.cla()
        plt.plot(loss_list, color='blue')
        plt.plot(loss_list2, color='red')


        if early_stopping and early_stopping.best_epoch is not None:
            plt.axvline(x=early_stopping.best_epoch, color='red', linestyle='--')


        if early_stopping is not None and early_stopping.stop_epoch is not None:
            plt.axvline(x=early_stopping.stop_epoch, color='black', linestyle='--')
        plt.title("Total Loss", fontdict=font_title)
        plt.legend(['Train', 'Val'], prop=font_legend, loc='upper right')
        plt.xlabel("Epochs", fontdict=font_label)
        plt.ylabel("Loss", fontdict=font_label)
        plt.xticks(fontsize=font_ticks['size'], fontfamily=font_ticks['family'])
        plt.yticks(fontsize=font_ticks['size'], fontfamily=font_ticks['family'])
        plt.xlim(0, 200)
        plt.tight_layout()
        plt.pause(0.01)
    if (epoch+1) % Epochs == 0 or (early_stopping and early_stopping.early_stop):
        plt.savefig(SavePath + "Loss")


def Saveloss(Epochs, mse_list1, mse_list2, edge_list1, edge_list2, SavePath):
    font_label = {'family': 'Times New Roman', 'size': 23}
    font_title = {'family': 'Times New Roman', 'size': 27}
    font_ticks = {'family': 'Times New Roman', 'size': 21}
    font_legend = font_manager.FontProperties(family='Times New Roman', size=21, weight='bold')
    plt.style.use("seaborn-v0_8")  # 美观风格
    fig2, ax2 = plt.subplots(figsize=(8, 6), constrained_layout=True)
    color_m = 'tab:green'
    color_e = 'tab:red'

    ax2.plot(mse_list1, label='Train MSE', color=color_m, linewidth=2, linestyle='-')
    ax2.plot(mse_list2, label='Val MSE', color=color_m, linewidth=2, linestyle='--')
    ax2.set_xlabel('Epochs', fontdict=font_label)
    ax2.set_ylabel('MSE Loss', color=color_m, fontdict=font_label)
    ax2.tick_params(axis='y', labelsize=font_ticks['size'], labelcolor=color_m)
    ax2.tick_params(axis='x', labelsize=font_ticks['size'])
    ax2.set_title('MSE (left) & Edge (right)', fontdict=font_title)

    ax2b = ax2.twinx()
    ax2b.plot(edge_list1, label='Train Edge', color=color_e, linewidth=2, linestyle='-')
    ax2b.plot(edge_list2, label='Val Edge', color=color_e, linewidth=2, linestyle='--')
    ax2b.set_ylabel('Edge Loss', color=color_e, fontdict=font_label)
    ax2b.tick_params(axis='y', labelsize=font_ticks['size'], labelcolor=color_e)


    legend_elements = [
        Line2D([0], [0], color='k', linestyle='-', linewidth=2, label='Train'),
        Line2D([0], [0], color='k', linestyle='--', linewidth=2, label='Val')
    ]
    ax2.legend(handles=legend_elements, prop=font_legend)
    ax2.tick_params(axis='x', labelsize=font_ticks['size'])
    # ax2.set_xticklabels(ax2.get_xticks(), fontfamily=font_ticks['family'])
    ax2.tick_params(axis='y', labelsize=font_ticks['size'], labelcolor=color_m)
    # ax2.set_yticklabels(ax2.get_yticks(), fontfamily=font_ticks['family'])
    ax2b.tick_params(axis='y', labelsize=font_ticks['size'], labelcolor=color_e)
    # ax2b.set_yticklabels(ax2b.get_yticks(), fontfamily=font_ticks['family'])
    # plt.show()
    ax2.set_xlim(0, 200)
    ax2b.set_xlim(0, 200)
    plt.tight_layout()
    plt.savefig(SavePath + "Comparation_Loss", bbox_inches='tight')
    ####################################################################################################################

def plot_weight(alpha_list, beta_list, SavePath):
    font_label = {'family': 'Times New Roman', 'size': 23}
    font_title = {'family': 'Times New Roman', 'size': 27}
    font_ticks = {'family': 'Times New Roman', 'size': 21}
    font_legend = font_manager.FontProperties(family='Times New Roman', size=21, weight='bold')
    plt.figure(figsize=(8, 6), constrained_layout=True)

    plt.plot(alpha_list, label="MSE Weight", color="blue")
    plt.plot(beta_list, label="EdgeLoss Weight", color="red")
    plt.xlabel("Epochs", fontdict=font_label)
    plt.ylabel("Weight", fontdict=font_label)
    plt.title("Weight Schedule", fontdict=font_title)
    plt.legend(prop=font_legend, loc='upper center')
    ax = plt.gca()
    ax.tick_params(axis='x', labelsize=font_ticks['size'])
    ax.tick_params(axis='y', labelsize=font_ticks['size'])
    ax.set_xlim(0, 200)
    plt.grid(True)
    # plt.show()
    plt.tight_layout()
    plt.savefig(SavePath + "weight")

def plot_contri(contrib_mse_list, contrib_edge_list, SavePath):
    font_label = {'family': 'Times New Roman', 'size': 23}
    font_title = {'family': 'Times New Roman', 'size': 27}
    font_ticks = {'family': 'Times New Roman', 'size': 21}
    font_legend = font_manager.FontProperties(family='Times New Roman', size=21, weight='bold')
    plt.figure(figsize=(8, 6), constrained_layout=True)
    # plt.plot(contrib_mse_list, label="MSE Contribution", color="blue")
    # plt.plot(contrib_edge_list, label="EdgeLoss Contribution", color="red")
    plt.plot([x * 100 for x in contrib_mse_list], label="MSE", color="blue")
    plt.plot([x * 100 for x in contrib_edge_list], label="EdgeLoss", color="red")
    plt.xlabel("Epochs", fontdict=font_label)
    plt.ylabel("Contribution (%)", fontdict=font_label)
    plt.title("Loss Contribution Over Training", fontdict=font_title)
    plt.legend(prop=font_legend, loc='upper right')
    ax = plt.gca()
    ax.tick_params(axis='x', labelsize=font_ticks['size'])
    ax.tick_params(axis='y', labelsize=font_ticks['size'])
    plt.grid(True)
    ax.set_xlim(0, 200)
    # plt.show()
    plt.tight_layout()
    plt.savefig(SavePath + "Contribution")

def SaveTestResults(TotPSNR, TotSSIM, Prediction, GT, SavePath):
    data = {}
    data['TotPSNR'] = TotPSNR
    data['TotSSIM'] = TotSSIM    
    data['GT'] = GT
    data['Prediction'] = Prediction
    scipy.io.savemat(SavePath+'TestResults',data) 
    
    
def PlotComparison(pd, gt, label_dsp_dim, label_dsp_blk, dh, minvalue, maxvalue, font2, font3,SavePath):
    PD = pd.reshape(label_dsp_dim[0], label_dsp_dim[1])
    PD = zoom(PD, (5, 5), order=3)
    savemat('output.mat', {'PD': PD})
    GT = gt.reshape(label_dsp_dim[0], label_dsp_dim[1])
    GT = zoom(GT, (5, 5), order=3)
    fig1, ax1 = plt.subplots(figsize=(7, 6))
    im1 = ax1.imshow(GT, extent=[0,label_dsp_dim[1]*label_dsp_blk[1]*dh,
                              0,label_dsp_dim[0]*label_dsp_blk[0]*dh],vmin=minvalue, vmax=maxvalue, cmap='jet')
    divider = make_axes_locatable(ax1)
    cax1 = divider.append_axes("right",size="5%",pad=0.05)
    plt.colorbar(im1, ax=ax1, cax=cax1).set_label('Velocity (m/s)', fontdict=font2)
    plt.tick_params(labelsize=12)
    for label in ax1.get_xticklabels()+ax1.get_yticklabels():
        label.set_fontsize(14)
    ax1.set_xlabel('Position (m)', font2)
    ax1.set_ylabel('Depth (m)', font2)
    ax1.set_title('Ground truth', font3)
    ax1.invert_yaxis()
    # plt.subplots_adjust(bottom=0.15, top=0.92, left=0.08, right=0.98)
    plt.savefig(SavePath+'GT', transparent=True)
    
    fig2, ax2 = plt.subplots(figsize=(7, 6))
    im2 = ax2.imshow(PD,extent=[0,label_dsp_dim[1]*label_dsp_blk[1]*dh,
                              0,label_dsp_dim[0]*label_dsp_blk[0]*dh],vmin=minvalue, vmax=maxvalue, cmap='jet')
    # plt.contour(np.flipud(GT),extent=[0, label_dsp_dim[1] * label_dsp_blk[1] * dh, 0, label_dsp_dim[0] * label_dsp_blk[0] * dh],levels=100, linestyles='--', colors='red', linewidths=0.5)
    divider2 = make_axes_locatable(ax2)
    cax2 = divider2.append_axes("right", size="5%", pad=0.05)
    plt.colorbar(im2, ax=ax2, cax=cax2).set_label('Velocity (m/s)', fontdict=font2)
    plt.tick_params(labelsize=12)  
    for label in ax2.get_xticklabels()+ax2.get_yticklabels():
        label.set_fontsize(14)   
    ax2.set_xlabel('Position (m)', font2)
    ax2.set_ylabel('Depth (m)', font2)
    ax2.set_title('Prediction', font3)
    ax2.invert_yaxis()
    # plt.subplots_adjust(bottom=0.15, top=0.92, left=0.08, right=0.98)
    plt.savefig(SavePath+'PD', transparent=True)
    plt.show()
    plt.close()


def PlotComparison_line(pd, gt, label_dsp_dim, label_dsp_blk, dh, minvalue, maxvalue, font2, font3, SavePath, col_indices):
    PD = pd.reshape(label_dsp_dim[0], label_dsp_dim[1])
    savemat('output.mat', {'PD': PD})
    GT = gt.reshape(label_dsp_dim[0], label_dsp_dim[1])
    fig1, ax1 = plt.subplots(figsize=(7, 6))
    im1 = ax1.imshow(GT, extent=[0, label_dsp_dim[1] * label_dsp_blk[1] * dh, 0, label_dsp_dim[0] * label_dsp_blk[0] * dh], vmin=minvalue, vmax=maxvalue, cmap='jet')

    # for y in row_indices:
    #     plt.axhline(y=y, color='k', linestyle='--', linewidth=2)


    for x in col_indices:
        plt.axvline(x=x, color='k', linestyle='--', linewidth=2)

    divider = make_axes_locatable(ax1)
    cax1 = divider.append_axes("right", size="5%", pad=0.05)
    plt.colorbar(im1, ax=ax1, cax=cax1).set_label('Velocity (m/s)', fontdict=font2)
    plt.tick_params(labelsize=12)
    for label in ax1.get_xticklabels() + ax1.get_yticklabels():
        label.set_fontsize(14)
    ax1.set_xlabel('Position (m)', font2)
    ax1.set_ylabel('Depth (m)', font2)
    ax1.set_title('Ground truth', font3)
    ax1.invert_yaxis()
    # plt.subplots_adjust(bottom=0.15, top=0.92, left=0.08, right=0.98)
    plt.savefig(SavePath + 'GT_line', transparent=True)
    plt.show()
    plt.close()


def edge_loss(out, target):

    x_filter = np.array([[1,0,-1],[2,0,-2],[1,0,-1]], dtype=np.float32)
    y_filter = np.array([[1,2,1],[0,0,0],[-1,-2,-1]], dtype=np.float32)


    C = out.shape[1]
    device = out.device
    weights_x = torch.from_numpy(x_filter).unsqueeze(0).unsqueeze(0).repeat(C,1,1,1).to(device)
    weights_y = torch.from_numpy(y_filter).unsqueeze(0).unsqueeze(0).repeat(C,1,1,1).to(device)


    g1_x = F.conv2d(out, weights_x, padding=1, groups=C)
    g2_x = F.conv2d(target, weights_x, padding=1, groups=C)
    g1_y = F.conv2d(out, weights_y, padding=1, groups=C)
    g2_y = F.conv2d(target, weights_y, padding=1, groups=C)


    g_1 = torch.sqrt(g1_x**2 + g1_y**2 + 1e-6)
    g_2 = torch.sqrt(g2_x**2 + g2_y**2 + 1e-6)


    return torch.mean(torch.abs(g_1 - g_2))




class EarlyStopping:
    def __init__(self, patience=5):
        self.patience = patience
        self.counter = 0
        self.best_loss = float('inf')

    def __call__(self, val_loss):
        if val_loss < self.best_loss:
            self.best_loss = val_loss
            self.counter = 0
        else:
            self.counter += 1
            if self.counter >=self.patience:
                return True
        return False
   